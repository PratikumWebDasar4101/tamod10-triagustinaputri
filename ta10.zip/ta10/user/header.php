<!DOCTYPE html>
<html>
    <head>
        <title>TA9</title>
        <link rel="stylesheet" href="..\css\bootstrap.min.css">
    </head>
    <body>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#">TA10</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="?halaman=TambahData">Tambah Data</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="?halaman=Profile">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../index.php?logout=yoi">Logout</a>
                    </li>
                </ul>
            </div>
        </nav>